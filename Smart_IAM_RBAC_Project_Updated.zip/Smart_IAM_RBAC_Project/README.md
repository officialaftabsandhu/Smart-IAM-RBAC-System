# Smart Identity and Access Management System with RBAC

A local academic project built with **Python Flask, SQLite, HTML, CSS and JavaScript**, following the Smart IAM presentation.

## Features

- Secure login with Werkzeug password hashing
- Three roles: Admin, Manager and User
- Role-based route protection (RBAC)
- Admin user management: create, update role and delete accounts
- Protected records and reports
- Manager/Admin record creation and editing
- Audit trail for login success/failure, logout, denied access and administrative actions
- SQLite database created automatically
- CSRF token validation for POST forms
- Parameterized SQL queries

## Requirements

- Python 3.9 or newer
- Internet is not required to run the application after Flask is installed. (The optional Google font in the stylesheet falls back to local fonts.)

## Setup on Windows

1. Extract the ZIP file.
2. Open the extracted `Smart_IAM_RBAC_Project` folder in VS Code.
3. Open Terminal in that folder.
4. Create a virtual environment:

   ```powershell
   py -m venv venv
   ```

5. Activate it:

   ```powershell
   .\venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\venv\Scripts\Activate.ps1
   ```

6. Install dependencies:

   ```powershell
   py -m pip install -r requirements.txt
   ```

7. Start the application:

   ```powershell
   py app.py
   ```

8. Open this address in your browser:

   `http://127.0.0.1:5000`

## Demo login accounts

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `Admin@123` |
| Manager | `manager` | `Manager@123` |
| User | `user` | `User@123` |

The database and demo accounts are created automatically on the first run.

## Role permissions

| Feature | Admin | Manager | User |
|---|:---:|:---:|:---:|
| Login | Yes | Yes | Yes |
| View protected reports | Yes | Yes | Yes |
| Create/edit records | Yes | Yes | No |
| Create user accounts | Yes | No | No |
| Change user roles | Yes | No | No |
| Delete user accounts | Yes | No | No |
| View audit logs | Yes | No | No |

## Database

The SQLite file `smart_iam.db` is created in the project folder when the application starts. It contains:

- `users` — account details, password hashes and roles
- `records` — protected sample resources
- `audit_logs` — recorded security events

To reset the demonstration database, stop the app, delete `smart_iam.db`, and start `py app.py` again. This recreates the three demo accounts and sample record.

## Suggested demonstration

1. Sign in as `admin` and show the dashboard.
2. Open User Management and create a new account with the User role.
3. Sign out and sign in as `manager`. Show that the manager can create/edit records but cannot open Admin pages.
4. Sign out and sign in as `user`. Show that the user can view reports but cannot edit records or manage users.
5. Sign back in as `admin` and open Audit Logs to show successful logins and denied access events.

## Security and academic-use note

This is a local educational prototype, not a production IAM service. Before any real deployment, use a strong randomly generated `SECRET_KEY`, disable Flask debug mode, configure HTTPS and secure cookies, add rate limiting and password reset controls, and review account lifecycle and backup requirements. The demo credentials must be changed before real use.


## Granular permission management (updated)

Admin can open **Permissions** from the sidebar and grant/revoke these per-user permissions:

- View protected reports
- Create new records
- Edit existing records
- Manage user accounts and roles (Admin-only module remains protected)
- View audit logs (Admin-only module remains protected)

The app stores assignments in `user_permissions` and checks them on the server. Existing databases are migrated automatically on startup; the initial defaults are Admin = all, Manager = reports/create/edit, User = reports only. Admin accounts retain full access.
