import os
import secrets
import sqlite3
from functools import wraps
from datetime import datetime, timezone

from flask import (
    Flask, render_template, request, redirect, url_for, flash,
    session, g, abort
)
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "smart_iam.db")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "development-only-change-this-secret")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


# -------------------- Database --------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DATABASE)
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('Admin', 'Manager', 'User')),
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            details TEXT NOT NULL,
            updated_by INTEGER,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS user_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            permission TEXT NOT NULL,
            UNIQUE(user_id, permission),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            username TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT NOT NULL,
            ip_address TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
        );
    """)

    # Demo accounts are created only when the database is first initialized.
    count = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if count == 0:
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        demo_users = [
            ("admin", "Admin@123", "Admin"),
            ("manager", "Manager@123", "Manager"),
            ("user", "User@123", "User"),
        ]
        for username, password, role in demo_users:
            db.execute(
                "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
                (username, generate_password_hash(password), role, now)
            )
        db.execute(
            "INSERT INTO records (title, details, updated_by, updated_at) VALUES (?, ?, NULL, ?)",
            ("Welcome record", "This is a sample protected record for the RBAC demonstration.", now)
        )
    # Migrate existing installations: add default granular permissions once.
    permission_count = db.execute("SELECT COUNT(*) FROM user_permissions").fetchone()[0]
    if permission_count == 0:
        defaults = {
            "Admin": ["reports.view", "records.create", "records.edit", "users.manage", "logs.view"],
            "Manager": ["reports.view", "records.create", "records.edit"],
            "User": ["reports.view"],
        }
        for uid, role in db.execute("SELECT id, role FROM users").fetchall():
            for permission in defaults.get(role, []):
                db.execute("INSERT OR IGNORE INTO user_permissions (user_id, permission) VALUES (?, ?)", (uid, permission))
    db.commit()
    db.close()


def log_event(action, details, user=None):
    db = get_db()
    user_id = user["id"] if user else None
    username = user["username"] if user else request.form.get("username", "Unknown")
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    db.execute(
        """INSERT INTO audit_logs (user_id, username, action, details, ip_address, created_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (user_id, username, action, details, ip, datetime.now(timezone.utc).isoformat(timespec="seconds"))
    )
    db.commit()


def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return get_db().execute("SELECT id, username, role, created_at FROM users WHERE id = ?", (user_id,)).fetchone()


# -------------------- CSRF protection --------------------

def csrf_token():
    if "_csrf_token" not in session:
        session["_csrf_token"] = secrets.token_urlsafe(32)
    return session["_csrf_token"]


@app.context_processor
def inject_globals():
    user = current_user()
    granted = set()
    if user and user["role"] != "Admin":
        granted = {row["permission"] for row in get_db().execute(
            "SELECT permission FROM user_permissions WHERE user_id = ?", (user["id"],)
        ).fetchall()}
    return {"csrf_token": csrf_token, "current_user": user, "user_permissions": granted}


@app.before_request
def protect_post_requests():
    if request.method == "POST":
        sent = request.form.get("_csrf_token", "")
        saved = session.get("_csrf_token", "")
        if not sent or not saved or not secrets.compare_digest(sent, saved):
            abort(400, description="Invalid or missing security token. Please refresh and try again.")


# -------------------- Authentication and RBAC --------------------

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*allowed_roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            user = current_user()
            if user["role"] not in allowed_roles:
                log_event("ACCESS_DENIED", f"Blocked {request.path}; required role: {', '.join(allowed_roles)}", user)
                flash("Access denied: your role does not have permission for this page.", "danger")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


PERMISSIONS = {
    "reports.view": "View protected reports",
    "records.create": "Create new records",
    "records.edit": "Edit existing records",
    "users.manage": "Manage user accounts and roles",
    "logs.view": "View audit logs",
}


def has_permission(user, permission):
    if not user:
        return False
    if user["role"] == "Admin":
        return True
    row = get_db().execute(
        "SELECT 1 FROM user_permissions WHERE user_id = ? AND permission = ?",
        (user["id"], permission)
    ).fetchone()
    return row is not None


def permission_required(permission):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            user = current_user()
            if not has_permission(user, permission):
                log_event("ACCESS_DENIED", f"Missing permission: {permission}; blocked {request.path}", user)
                flash("Access denied: this account has not been granted that permission.", "danger")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


@app.route("/")
def index():
    return redirect(url_for("dashboard") if current_user() else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["_csrf_token"] = secrets.token_urlsafe(32)
            log_event("LOGIN_SUCCESS", "User logged in successfully", user)
            flash(f"Welcome, {user['username']}!", "success")
            return redirect(url_for("dashboard"))
        log_event("LOGIN_FAILED", "Invalid username or password")
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.post("/logout")
@login_required
def logout():
    user = current_user()
    log_event("LOGOUT", "User logged out", user)
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    db = get_db()
    stats = {
        "users": db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "records": db.execute("SELECT COUNT(*) FROM records").fetchone()[0],
        "events": db.execute("SELECT COUNT(*) FROM audit_logs").fetchone()[0],
    }
    recent_logs = db.execute(
        "SELECT username, action, details, created_at FROM audit_logs ORDER BY id DESC LIMIT 6"
    ).fetchall() if user["role"] == "Admin" else []
    return render_template("dashboard.html", user=user, stats=stats, recent_logs=recent_logs)


# -------------------- Protected resources --------------------

@app.route("/reports")
@permission_required("reports.view")
def reports():
    records = get_db().execute("SELECT * FROM records ORDER BY id DESC").fetchall()
    return render_template("reports.html", records=records)


@app.route("/records/<int:record_id>/edit", methods=["POST"])
@permission_required("records.edit")
def edit_record(record_id):
    title = request.form.get("title", "").strip()
    details = request.form.get("details", "").strip()
    if not title or not details:
        flash("Both title and details are required.", "warning")
        return redirect(url_for("reports"))
    db = get_db()
    record = db.execute("SELECT id FROM records WHERE id = ?", (record_id,)).fetchone()
    if not record:
        abort(404)
    user = current_user()
    db.execute(
        "UPDATE records SET title = ?, details = ?, updated_by = ?, updated_at = ? WHERE id = ?",
        (title, details, user["id"], datetime.now(timezone.utc).isoformat(timespec="seconds"), record_id)
    )
    db.commit()
    log_event("RECORD_UPDATED", f"Updated record #{record_id}: {title}", user)
    flash("Record updated successfully.", "success")
    return redirect(url_for("reports"))


@app.post("/records/create")
@permission_required("records.create")
def create_record():
    title = request.form.get("title", "").strip()
    details = request.form.get("details", "").strip()
    if not title or not details:
        flash("Both title and details are required.", "warning")
        return redirect(url_for("reports"))
    user = current_user()
    db = get_db()
    cur = db.execute(
        "INSERT INTO records (title, details, updated_by, updated_at) VALUES (?, ?, ?, ?)",
        (title, details, user["id"], datetime.now(timezone.utc).isoformat(timespec="seconds"))
    )
    db.commit()
    log_event("RECORD_CREATED", f"Created record #{cur.lastrowid}: {title}", user)
    flash("New record created.", "success")
    return redirect(url_for("reports"))


# -------------------- Admin user management --------------------

@app.route("/admin/users")
@permission_required("users.manage")
def users():
    rows = get_db().execute("SELECT id, username, role, created_at FROM users ORDER BY id").fetchall()
    return render_template("users.html", users=rows)


@app.post("/admin/users/create")
@permission_required("users.manage")
def create_user():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    role = request.form.get("role", "")
    if len(username) < 3 or len(password) < 8 or role not in ("Admin", "Manager", "User"):
        flash("Use a username of at least 3 characters, a password of at least 8 characters, and a valid role.", "warning")
        return redirect(url_for("users"))
    if role == "Admin" and current_user()["role"] != "Admin":
        flash("Only an Admin can create another Admin account.", "danger")
        return redirect(url_for("users"))
    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
            (username, generate_password_hash(password), role, datetime.now(timezone.utc).isoformat(timespec="seconds"))
        )
        new_user_id = cur.lastrowid
        default_permissions = {
            "Admin": list(PERMISSIONS.keys()),
            "Manager": ["reports.view", "records.create", "records.edit"],
            "User": ["reports.view"],
        }
        for permission in default_permissions[role]:
            db.execute("INSERT OR IGNORE INTO user_permissions (user_id, permission) VALUES (?, ?)", (new_user_id, permission))
        db.commit()
        log_event("USER_CREATED", f"Created account '{username}' with role {role}", current_user())
        flash("User account created.", "success")
    except sqlite3.IntegrityError:
        flash("That username already exists.", "danger")
    return redirect(url_for("users"))


@app.post("/admin/users/<int:user_id>/role")
@permission_required("users.manage")
def update_role(user_id):
    role = request.form.get("role", "")
    if role not in ("Admin", "Manager", "User"):
        flash("Invalid role.", "danger")
        return redirect(url_for("users"))
    if role == "Admin" and current_user()["role"] != "Admin":
        flash("Only an Admin can promote an account to Admin.", "danger")
        return redirect(url_for("users"))
    if user_id == current_user()["id"]:
        flash("For safety, you cannot change your own role.", "warning")
        return redirect(url_for("users"))
    db = get_db()
    target = db.execute("SELECT username FROM users WHERE id = ?", (user_id,)).fetchone()
    if not target:
        abort(404)
    db.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
    db.commit()
    log_event("ROLE_UPDATED", f"Changed {target['username']}'s role to {role}", current_user())
    flash("User role updated.", "success")
    return redirect(url_for("users"))


@app.post("/admin/users/<int:user_id>/delete")
@permission_required("users.manage")
def delete_user(user_id):
    if user_id == current_user()["id"]:
        flash("You cannot delete your own account while logged in.", "warning")
        return redirect(url_for("users"))
    db = get_db()
    target = db.execute("SELECT username, role FROM users WHERE id = ?", (user_id,)).fetchone()
    if not target:
        abort(404)
    if target["role"] == "Admin" and current_user()["role"] != "Admin":
        flash("Only an Admin can delete another Admin account.", "danger")
        return redirect(url_for("users"))
    db.execute("DELETE FROM users WHERE id = ?", (user_id,))
    db.commit()
    log_event("USER_DELETED", f"Deleted account '{target['username']}'", current_user())
    flash("User deleted.", "success")
    return redirect(url_for("users"))


@app.route("/admin/permissions")
@roles_required("Admin")
def permissions():
    db = get_db()
    users_list = db.execute("SELECT id, username, role FROM users ORDER BY username").fetchall()
    assigned = {}
    for item in users_list:
        assigned[item["id"]] = {r["permission"] for r in db.execute(
            "SELECT permission FROM user_permissions WHERE user_id = ?", (item["id"],)
        ).fetchall()}
    return render_template("permissions.html", users=users_list, permissions=PERMISSIONS, assigned=assigned)


@app.post("/admin/permissions/<int:user_id>")
@roles_required("Admin")
def save_permissions(user_id):
    db = get_db()
    target = db.execute("SELECT username, role FROM users WHERE id = ?", (user_id,)).fetchone()
    if not target:
        abort(404)
    if target["role"] == "Admin":
        flash("Admin accounts always retain full access.", "warning")
        return redirect(url_for("permissions"))
    selected = set(request.form.getlist("permissions"))
    selected.intersection_update(PERMISSIONS.keys())
    db.execute("DELETE FROM user_permissions WHERE user_id = ?", (user_id,))
    for permission in selected:
        db.execute("INSERT INTO user_permissions (user_id, permission) VALUES (?, ?)", (user_id, permission))
    db.commit()
    log_event("PERMISSIONS_UPDATED", f"Updated permissions for {target['username']}: {', '.join(sorted(selected)) or 'none'}", current_user())
    flash(f"Permissions saved for {target['username']}.", "success")
    return redirect(url_for("permissions"))


@app.route("/admin/logs")
@permission_required("logs.view")
def logs():
    rows = get_db().execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200").fetchall()
    return render_template("logs.html", logs=rows)


@app.errorhandler(400)
def bad_request(error):
    return render_template("error.html", code=400, message=getattr(error, "description", "Bad request")), 400


@app.errorhandler(403)
def forbidden(error):
    return render_template("error.html", code=403, message="You are not allowed to access this resource."), 403


@app.errorhandler(404)
def not_found(error):
    return render_template("error.html", code=404, message="The requested page or record was not found."), 404


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
