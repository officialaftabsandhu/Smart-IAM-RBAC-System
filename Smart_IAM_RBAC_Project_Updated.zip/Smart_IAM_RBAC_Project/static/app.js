document.addEventListener("click", function (event) {
  const button = event.target.closest(".edit-toggle");
  if (!button) return;
  const target = document.getElementById(button.dataset.target);
  if (target) target.classList.toggle("hidden");
});
